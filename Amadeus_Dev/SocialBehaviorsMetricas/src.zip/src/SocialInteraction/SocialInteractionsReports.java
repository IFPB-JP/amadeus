package SocialInteraction;

import java.util.*;

import org.apache.commons.collections.*;  
import org.apache.commons.collections.collection.*;  
import org.apache.commons.collections.MultiMap;   
import org.apache.commons.collections.map.*;

import edu.uci.ics.jung.algorithms.importance.BetweennessCentrality;
import edu.uci.ics.jung.algorithms.scoring.ClosenessCentrality;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import edu.uci.ics.jung.graph.util.EdgeType;
import edu.uci.ics.jung.io.GraphMLWriter;

import java.util.Date;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class SocialInteractionsReports {
	
	/*
	 * Constructor
	 */
	public SocialInteractionsReports(){
		
	}
	
	/*
	 * Criação do grafo dirigido a partir das interações sociais nas ferramentas de comunicação Amadeus
	 */
	public DirectedSparseMultigraph<String,String> generateGhaph(ArrayList<String> actors, MultiMap interactions){
		
		DirectedSparseMultigraph<String, String> graph = new DirectedSparseMultigraph<String,String>();
		ArrayList<String> edges;
		
		for (String i:actors){
			graph.addVertex(i);
		}
		
		for (String j:actors){
			edges = (ArrayList<String>)interactions.get(j);
			if (edges != null){
				for (String i:edges){
					graph.addEdge("edge" + j + "" + i, j, i, EdgeType.DIRECTED);
				}
			}
			
		}
	    
		//System.out.println(graph.getEdgeCount());
		//System.out.println(graph);
		return graph;
	}
	
	
	/*
	 * Método que calcula a coesão do grupo da rede social através da aplicação
	 * da métrica densidade de Análise de Redes Sociais
	 */
	
	public String cohesionGroup(ArrayList<String> actors, MultiMap interactions){
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		Collection<String> edges = graph.getEdges();
		
		double numArcs = (double)edges.size();
		
		double numActors = (double)actors.size();
		
		double density = (numArcs / (numActors * (numActors - 1)));
		
		Double density1 = new Double(density);
		
		double p = Math.pow(10, 4);  
		
		Double densityFormated = Math.round(density1 * p) / p;
		
		// Save graph
		
		this.saveGraph(graph);
		
		return this.reportCohesion(densityFormated.toString());
		
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre a coesão dos alunos da turma
	 */
	
	public String reportCohesion(String density){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Cohesion Degree**        " + data + "\n"+ "\n"+ "Is a measure used to evaluate how cohesive is a social group. This behavior also "+ "\n"+ "indicates the level of group interactivity and offers to the teacher a diagnosis " + "\n" + "of how cohesive is the group of student. This gives an indication of the general level of engagement in the network.";
		
		String result = "Cohesion Degree: " + density;
		
		double densityDouble = Double.parseDouble(density); 
		
		String diagnosis = this.cohesionScale(densityDouble);
		
		String intervention = "If cohesion degree presents no cohesion ou weak cohesion, the teacher can foster more collaboration on communication tools";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + diagnosis + "\n" + "\n" + "Intervention" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método que retorna o grau de coesão do grupo baseado na densidade calculada
	 */
	public String cohesionScale(double density){
		
		if (density == 0.0){
			return "No cohesive group";
		} else if (density > 0.0 && density <= 0.2){
			return "Weakly cohesive group";
		} else if (density > 0.2 && density <= 0.5){
			return "Cohesive group";
		} else if (density > 0.5 && density <= 1){
			return "Strongly cohesive group";
		} else {
			return "Completely cohesive group";
		}
		
	}
	

	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * o prestígio dos estudantes de uma rede social
	 */
	public String prestigePerStudent(ArrayList<String> actors, MultiMap interactions){
		
		
		Map<String,Integer> indegreeValues = this.prestigeStudentsValued(actors, interactions);
		
		
		Map<String,Integer> sortedMap = this.sortMap(indegreeValues);
		
		// Save graph
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		this.saveGraph(graph);
		
		return this.reportPrestige(sortedMap);
	
	}
	
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre o prestígio dos alunos do curso
	 */
	
	public String reportPrestige(Map<String,Integer> indegreeValue){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Prestige Degree**          "+ data  +  "\n"+ "\n"+ "Is a measure used to quantify prestige heterogeneity, ie, choices received. The prestige, ou status, of an student is equal to the number of interactions terminating at this student, ie, the interest of other students";
		
		String result = "Prestige Degree: ";
		
		// Print Map (Strudent - Prestige)
		
		Collection<String> unsorted = indegreeValue.keySet();
		
		String[] array = (String[]) unsorted.toArray(new String[unsorted.size()]);
		
		for (String key : array) {
			
			result += "\n"+ key + " - "+ indegreeValue.get(key) + " ";
			
		}
		
		//Arredonda para cima
		int qtdInteractions = (int)Math.ceil((30 * unsorted.size())/100.0);
		
		
		String diagnosis = "Student(s) "+ this.bigger(array, qtdInteractions) + " has/have greater prestige face his colleagues, while student(s) "+ this.smaller(array, qtdInteractions) + " has/have less prestige face his colleagues" ;
		
		String intervention = "Using a collaborative tool to suggest to students with a greater degree of prestige that interacting with students with lesser degrees of prestige, to motivate them.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	
	/*
	 * Método que recebe um MultiMap com as interacoes sociais dos estudantes e retorna o prestígio
	 * de cada estudante baseado na quantidade de interações que finalizam no estudante.São consideradas
	 * as interações repetidas entre os estudantes, diferentemente do método indegree da classe DirectedSparseMultigraph
	 */
	public Map<String,Integer> prestigeStudentsValued(ArrayList<String> actors, MultiMap interactions){
		
		Map<String,Integer> prestige = new HashMap<String,Integer>();
		int cont = 0;
		
		Collection<String> col = interactions.values();
		ArrayList<String> interactionsEnd = new ArrayList<String>(col);
		
		for (String i:actors){
			for (String j:interactionsEnd){
					if (i.equals(j)){
						cont++;
					}
			}
			prestige.put(i, cont);
			cont = 0;
		}
		
		return prestige;
		
	}
	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * o engajamento dos estudantes de uma rede social
	 */
	public String engagementPerStudent(ArrayList<String> actors, MultiMap interactions){
		
		Map<String,Integer> indegreeValues = this.engagementStudentsValued(actors, interactions);
		
		Map<String,Integer> sortedMap = this.sortMap(indegreeValues);
		
		// Save graph
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
				
		this.saveGraph(graph);
		
		return this.reportEngagement(sortedMap);
		
	
	}
	
	/*
	 * Método que recebe um MultiMap com as interacoes sociais dos estudantes e retorna o grau de engajamento
	 * de cada estudante baseado na quantidade de interações que começam com o estudante.São consideradas
	 * as interações repetidas entre os estudantes, diferentemente do método outdegree da classe DirectedSparseMultigraph
	 */
	public Map<String,Integer> engagementStudentsValued(ArrayList<String> actors, MultiMap interac){
		
		MultiValueMap interactions = (MultiValueMap)interac;
		Map<String,Integer> engagement = new HashMap<String,Integer>();
		int cont = 0;
		
		for (String i:actors){
			cont = interactions.size(i);
			engagement.put(i, cont);
			cont = 0;
			//System.out.println("Engajamento: " + engagement);
		}
		
		return engagement;
		
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre o prestígio dos alunos do curso
	 */
	
	public String reportEngagement(Map<String,Integer> indegreeValue){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Engagement Degree**         "+ data + "\n"+ "\n"+ "The engagement of an student is equal to the number of interactions begining at this student and describe the extent to which participants learn actively. The number of interactions beginning at a student suggest initiation of engagement or discourse. ";
		
		String result = "Engagement Degree: ";
		
		Collection<String> unsorted = indegreeValue.keySet();
		
		String[] array = (String[]) unsorted.toArray(new String[unsorted.size()]);
		
		for (String key : array) {
			
			result += "\n"+ key + " - "+ indegreeValue.get(key) + " ";
			
		}
		
		//Arredonda para cima
		int qtdInteractions = (int)Math.ceil((30 * unsorted.size())/100.0);
		
		
		String diagnosis = "Student(s) "+ this.bigger(array, qtdInteractions) + " has/have greater engagement face his colleagues, while student(s) "+ this.smaller(array, qtdInteractions) + " has/have less engagement face his colleagues" ;
		
		String intervention = "To increase engagement, the teacher should seek ways to encourage a more active attitude of the students, especially those who have a low level of engagement, so that they interact more with his colleagues in the different communication tools available. Thinking about students in general, propose activities or challenging jobs, which require students to conduct research outside of the virtual learning environment and to collaborate with each other, building knowledge together. Direct intervention: Send messages to students with lower levels of engagement and ask them to give their opinions or submit a solution or even indicate a source of research on some specific discussion on environmental communication tool.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * a visibilidade ou amplitude da interatividade dos estudantes de uma rede social
	 */
	public String visibilityPerStudent(ArrayList<String> actors, MultiMap interactions){
		
		Map<String,Integer> outdegreeValues = this.outdegree(actors, interactions);
		
		
		Map<String,Integer> sortedMap = this.sortMap(outdegreeValues);
		
		
		Map<String,Double> visibilityResult = centralityPerStudent(sortedMap);
			
		
		return this.reportVisibility(visibilityResult);
		
	
	}
	
	/*
	 * Método que recebe o outdegree de todos os estudantes na forma de um Map e retorna, também através,
	 * de um Map o grau de centralidade de cada estudante do curso.
	 */
	public Map<String,Double> centralityPerStudent(Map<String,Integer> outdegree){
			
		ArrayList<Double> centralities = new ArrayList<Double>();
		
		ArrayList<Integer> outdegrees = new ArrayList<Integer>(outdegree.values());
		
		Map<String,Double> centralityList = new LinkedHashMap<String,Double>();
		
		Collection<String> keys = outdegree.keySet();
		ArrayList<String> keysList = new ArrayList<String>(keys);
		
		int groupSize = outdegrees.size() - 1;
		double groupSizeDouble = (double)groupSize;
		
		//System.out.println(groupSizeDouble);
		
		double p;
		Double centralityFormated;
		double outdegreeValues;
		int cont = 0;
		for (int i:outdegrees){
			outdegreeValues = (double)outdegrees.get(cont)/groupSizeDouble;
			p = Math.pow(10, 4);  
			centralityFormated = Math.round(outdegreeValues * p) / p;
			//System.out.println(outdegreeValues);
			centralities.add(centralityFormated);
			centralityList.put(keysList.get(cont), centralities.get(cont));
			cont++;
		}
		
		return centralityList;
		
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre o visibilidade (nível de interatividade) dos alunos do curso
	 */
	
	public String reportVisibility(Map<String,Double> indegreeValue){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Visibility Degree**       "+ data + "\n"+ "\n"+ "The visibility of an student is a measure used to measure the quantity of direct interactions that an actor have inside the social network and it’s calculated through the Centrality Degree metrics. According to the centrality degree of an actor means the identification of the position in where it is found relative to exchange and communication in the network. If we compare the centrality degree for different students of a group, we can determine if the interaction if centralized in a little group of students of distributed more uniformly. ";
		
		String result = "Visibility Degree: ";
		
		Collection<String> unsorted = indegreeValue.keySet();
		
		String[] array = (String[]) unsorted.toArray(new String[unsorted.size()]);
		
		for (String key : array) {
			
			result += "\n"+ key + " - "+ indegreeValue.get(key) + " ";
			
		}
		
		//Arredonda para cima
		int qtdInteractions = (int)Math.ceil((30 * unsorted.size())/100.0);
		
		
		String diagnosis = "Student(s) "+ this.bigger(array, qtdInteractions) + " has/have greater visibility/centrality face his colleagues, while student(s) "+ this.smaller(array, qtdInteractions) + " has/have less visibility/centrality face his colleagues" ;
		
		String intervention = "To increase visibility o professor deve encourajar, especialmente estudantes com baixo grau de visibilidade/centralidade, a utilização maior das diferentes ferramentas de comunicação existentes no Amadeus.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * a heterogeneidade de um grupo de estudantes de uma rede social.
	 */
	public String heterogeneityGroup(ArrayList<String> actors, MultiMap interactions){
		
		Map<String,Integer> outdegreeValues = this.outdegree(actors, interactions);
		
		
		Map<String,Integer> sortedMap = this.sortMap(outdegreeValues);
		
		
		Map<String,Double> visibilityResult = centralityPerStudent(sortedMap);
		
		
		Map<String,Double> biggerCentralityMinusCentralities =  this.calculateDifferenceBetweenBiggerAndOthers(visibilityResult);
		
		
		Double heterogeneityDegree = this.calculateHeterogeneityDegree(biggerCentralityMinusCentralities);
		
		
		return this.reportHeterogeneity(heterogeneityDegree);
		
	
	}
	
	/*
	 * Método que calcula a diferença do estudante com maior centralidade da centralidade de todos os estudantes, armazenando
	 * em um Map, que é retornado. Parte do cálculo do grau de heterogeneidade do grupo.
	 */
	public Map<String,Double> calculateDifferenceBetweenBiggerAndOthers(Map<String,Double> visibilityDegree){
		
		ArrayList<Double> centralities = new ArrayList<Double>();
		
		ArrayList<Double> biggerMinusCentralities = new ArrayList<Double>(visibilityDegree.values());
		
		Map<String,Double> centralityList = new LinkedHashMap<String,Double>();
		
		Double bigCentrality = biggerMinusCentralities.get(0);
		
		Collection<String> keys = visibilityDegree.keySet();
		
		ArrayList<String> keysList = new ArrayList<String>(keys);
		
		double centralityValues;
		int cont = 0;
		for (double i:biggerMinusCentralities){
			centralityValues = bigCentrality - biggerMinusCentralities.get(cont);
			centralities.add(centralityValues);
			centralityList.put(keysList.get(cont), centralities.get(cont));
			cont++;
		}
		
		return centralityList;
		
	}
	
	/*
	 * Método que calcula o grau de heterogeneidade do grupo.
	 */
	public Double calculateHeterogeneityDegree(Map<String,Double> visibilityDegree){
		
		ArrayList<Double> biggerMinusCentralities = new ArrayList<Double>(visibilityDegree.values());
		
		int groupSize = visibilityDegree.size() - 1;
		double groupSizeDouble = (double)groupSize;
		
		Double sumCentralities = biggerMinusCentralities.get(0);
		
		int cont = 0;
		for (double i:biggerMinusCentralities){
			sumCentralities += biggerMinusCentralities.get(cont++);
		}
		
		return sumCentralities/(Math.pow(groupSizeDouble, 2));
		
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre a coesão dos alunos da turma
	 */
	
	public String reportHeterogeneity(Double heterogeneity){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Heterogeneity Degree**        "+ data + "\n"+ "\n"+ "Is a measure used to discover the variability of the individual actor indices from a social network. Offer the teacher an indication of how much heterogeneous, based on students social interactions, is the group of students.";
		
		// Formatar o grau de heterogeneidade
		
		double p = Math.pow(10, 4);  
		
		Double heterogeneityFormated = Math.round(heterogeneity * p) / p; 
        
        String result = "Heteroneity Degree: " + heterogeneityFormated;
		
		
		String diagnosis = "Heterogeneity degree varies from 0 to 1, which means that the lower the value, the group is more heterogeneous. If the degree of centrality approaches 1, meaning that a small number of students are central, while others are considered less central, ie, are located on the periphery of the social network.";
		
		String intervention = "The proposed interventions in individual social behavior metrics visibility degree, isolation degree and engagement degree, should foster a more heterogeneous social group. Teachers should regularly monitor this metric and compare the results.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * o grau de intermediação da informação dos estudantes (individualmente) de uma rede social
	 */
	public String informationIntermediationPerStudent(ArrayList<String> actors, MultiMap interactions){
		
		int sizeGroup = actors.size();
		
		Map<String,Double> betweenness = new HashMap<String,Double>();
		
		Map<String,Double> betweennessSorted = new HashMap<String,Double>();
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		BetweennessCentrality ranker = new BetweennessCentrality(graph);
		
		ranker.setRemoveRankScoresOnFinalize(false);
		
		ranker.evaluate();
		
		//ranker.printRankings(true, false);
		
		double bet, finalBet, p;
		Double intermediationFormated;
		
		for (String actor:actors){
			
			bet = ranker.getVertexRankScore(actor);
			finalBet = bet/((sizeGroup-2) * (sizeGroup-1));
			p = Math.pow(10, 4);  
			
			intermediationFormated = Math.round(finalBet * p) / p; 
			betweenness.put(actor, intermediationFormated);
			
		}
	
		betweennessSorted = this.sortMapDouble(betweenness);
		
		// Save graph
		
		this.saveGraph(graph);
		
		return this.reportIntermediationInformation(betweennessSorted);
	
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre o visibilidade (nível de interatividade) dos alunos do curso
	 */
	
	public String reportIntermediationInformation(Map<String,Double> indegreeValue){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Intermediation Information Degree**     "+ data  + "\n"+ "\n"+ "Is a measure used to determine the number of minimum paths between all the pairs of actors in a graph that passes through one determine actor. In the context of the interaction between students, a student might not have a high direct interaction degree with its colleagues, or even might not establish strong links inside the social network, although the same can be a paramount for the mediation of information between the nonadjacent actors.";
		
		String result = "Intermediation Information Degree: ";
		
		Collection<String> unsorted = indegreeValue.keySet();
		
		String[] array = (String[]) unsorted.toArray(new String[unsorted.size()]);
		
		for (String key : array) {
			
			result += "\n"+ key + " - "+ indegreeValue.get(key) + " ";
			
		}
		
		//Arredonda para cima
		int qtdInteractions = (int)Math.ceil((30 * unsorted.size())/100.0);
		
		
		String diagnosis = "Student(s) "+ this.bigger(array, qtdInteractions) + " has/have greater intermediation information degree face his colleagues, while student(s) "+ this.smaller(array, qtdInteractions) + " has/have less intermediation information degree face his colleagues. The teacher is able to identify which group members, whose absence can break the cycle of information transmission, since their removal can break the group into several subgroups." ;
		
		String intervention = "The teacher could act so as to start discussions or questions from the students closer to the other, ie, students with lower isolation degree. Thus, the information will come soon to all members of the group and consequently generates a new discussion as quickly as possible among all participants.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método, invocado pela interface de monitoramento de interações sociais, que calcula e analisa
	 * o grau de intermediação da informação dos estudantes (individualmente) de uma rede social
	 */
	public String isolationPerStudent(ArrayList<String> actors, MultiMap interactions){
		
		int sizeGroup = actors.size();
		
		Map<String,Double> closeness = new HashMap<String,Double>();
		
		Map<String,Double> closenessSorted = new HashMap<String,Double>();
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		ClosenessCentrality ranker = new ClosenessCentrality(graph);
		
		
		double bet, finalBet, p;
		Double intermediationFormated;
		
		for (String actor:actors){
			
			bet = ranker.getVertexScore(actor);
			p = Math.pow(10, 4);  
			
			intermediationFormated = Math.round(bet * p) / p; 
			closeness.put(actor, intermediationFormated);
			
		}
	
		closenessSorted = this.sortMapDouble(closeness);
		
		// Save graph
		
		this.saveGraph(graph);
		
		return this.reportIsolation(closenessSorted);
	
	}
	
	/*
	 * Método que gera o relatório que será oferecido ao professor sobre o visibilidade (nível de interatividade) dos alunos do curso
	 */
	
	public String reportIsolation (Map<String,Double> indegreeValue){
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		String head = "**Isolation Degree**      "+ data + "\n"+ "\n"+ " Is a measure used to determine the shortest geodesic distance between an actor and all of the other actors on the social network, how close each student is from other students. In the context of the interaction between students, this service offers the teacher an indication of the possible isolated students in the group.";
		
		String result = "Isolation Degree: ";
		
		Collection<String> unsorted = indegreeValue.keySet();
		
		String[] array = (String[]) unsorted.toArray(new String[unsorted.size()]);
		
		for (String key : array) {
			
			result += "\n"+ key + " - "+ indegreeValue.get(key) + " ";
			
		}
		
		//Arredonda para cima
		int qtdInteractions = (int)Math.ceil((30 * unsorted.size())/100.0);
		
		
		String diagnosis = "Student(s) "+ this.bigger(array, qtdInteractions) + " has/have greater isolation degree degree face his colleagues, while student(s) "+ this.smaller(array, qtdInteractions) + " has/have less isolation degree face his colleagues. It is possible identify communication difficulties among students caused by the null or low isolation degree of students. This may mean that many messages/comments are not reaching some students, these being excluded, or distanced, the others" ;
		
		String intervention = "The absence of students with higher degree of intermediation of information in the social network can isolate communication between other students. The teacher should review the graph and suggest that students with higher levels of information intermediation interact with students that he has not interacted, increases the reach of social networking. Students with a higher level of intermediation of information must be orientated over their role and responsibility in the social group.";
		
		return head + "\n" +"\n" + result + "\n" +"\n" + "Diagnosis: " + "\n"  + diagnosis + "\n" + "\n" + "Intervention:" + "\n" + intervention  ;
		
	}
	
	/*
	 * Método, que deve ser invocado por todas os comportamentos (métricas) relacionadas a cada ator
	 * que retorna na forma de uma String, os nomes dos estudantes (%) com maior grau
	 */
	public String bigger(String[] array, int size){
		
		String list = " ";
		
		for (int i = 0; i < size; i++){
			list += array[i] + ", ";
		}

		
		return list;
		
	}
	
	/*
	 * Método, que deve ser invocado por todas os comportamentos (métricas) relacionadas a cada ator
	 * que retorna na forma de uma String, os nomes dos estudantes (%) com maior grau
	 */
	public String smaller(String[] array, int size){
		
		String list = " ";
		
		for (int i = array.length-1; i >= (array.length - size); i--){
			list += array[i] + ", ";
		}

		
		return list;
		
	}
	
	/*
	 * Ordena os estudantes, em ordem decrescente, baseado em alguma métrica de Análise de Redes Sociais. Este método será
	 * chamado por todas as métricas representadas por Integer no momento de gerar o relatório.
	 */
	
	public Map<String,Integer> sortMap(Map<String,Integer> indegreeValue){
	
		Map<String,Integer> newIndegreeValue = new LinkedHashMap<String,Integer>();
		// Local variables
		Integer currentValue;
		int cont;
		String next;
		String bigKey;
		Integer bigValue;
		Collection col;
		ArrayList<Integer> noSortedValues;
		Collection<String> unsortedKeys;
		Iterator it;
		String[] array;
		int sizeMap = indegreeValue.size();
		
		for (int i = 0; i< sizeMap; i++){
			
				col = indegreeValue.values();
				
				noSortedValues = new ArrayList<Integer>(col);
				
				unsortedKeys = indegreeValue.keySet();
				
				it = unsortedKeys.iterator();
			
				array = (String[]) unsortedKeys.toArray(new String[unsortedKeys.size()]);		
				
				//Encontrar o maior valor
				cont = 0;
				next= (String)it.next();
				bigKey = next;
				//bigIndex = cont;
				bigValue = noSortedValues.get(cont);
				while (it.hasNext()){
					cont++;
					next = (String)it.next();
					//currentValue = indegreeValue.get(noSortedValues.get(cont));
					currentValue = noSortedValues.get(cont);
					if (currentValue.intValue() >= bigValue){
					    //bigIndex = cont;
						bigValue = currentValue;
						bigKey = next;
					}
				}
				
				indegreeValue.remove(bigKey);
				newIndegreeValue.put(bigKey, bigValue);				
		
			}
			
			return newIndegreeValue;
		
	}
	
	/*
	 * Ordena os estudantes, em ordem decrescente, baseado em alguma métrica de Análise de Redes Sociais. Este método será
	 * chamado por todas as métricas representadas por Double no momento de gerar o relatório.
	 */
	
	public Map<String,Double> sortMapDouble(Map<String,Double> indegreeValue){
		
		Map<String,Double> newIndegreeValue = new LinkedHashMap<String,Double>();
		// Local variables
		Double currentValue;
		int cont;
		String next;
		String bigKey;
		Double bigValue;
		Collection col;
		ArrayList<Double> noSortedValues;
		Collection<String> unsortedKeys;
		Iterator it;
		String[] array;
		int sizeMap = indegreeValue.size();
		
		for (int i = 0; i< sizeMap; i++){
			
				col = indegreeValue.values();
				
				noSortedValues = new ArrayList<Double>(col);
				
				unsortedKeys = indegreeValue.keySet();
				
				it = unsortedKeys.iterator();
			
				array = (String[]) unsortedKeys.toArray(new String[unsortedKeys.size()]);		
				
				//Encontrar o maior valor
				cont = 0;
				next= (String)it.next();
				bigKey = next;
				//bigIndex = cont;
				bigValue = noSortedValues.get(cont);
				while (it.hasNext()){
					cont++;
					next = (String)it.next();
					//currentValue = indegreeValue.get(noSortedValues.get(cont));
					currentValue = noSortedValues.get(cont);
					if (currentValue >= bigValue){
					    //bigIndex = cont;
						bigValue = currentValue;
						bigKey = next;
					}
				}
				
				indegreeValue.remove(bigKey);
				newIndegreeValue.put(bigKey, bigValue);				
		
			}
			
			return newIndegreeValue;
		
	}
	
	/*
	 * Método que calcula o índice indegree de cada estudante da rede social através da aplicação
	 * da métrica indegree de Análise de Redes Sociais e retorna um Map com o nome do estudante
	 * e o indegree.
	 */
	
	public Map<String,Integer> indegree(ArrayList<String> actors, MultiMap interactions){
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		Collection<String> vertices = graph.getVertices();
		
		Map<String,Integer> indegreeValue = new HashMap<String, Integer>();
		
		int in;
		
		for (String student:vertices){
			in = graph.inDegree(student);
			indegreeValue.put(student, in);
		}
		
		// Save graph
		
		this.saveGraph(graph);
		
		return indegreeValue;
	}
	
	/*
	 * Método que calcula o índice outdegree de cada estudante da rede social através da aplicação
	 * da métrica outdegree de Análise de Redes Sociais e retorna um Map com o nome do estudante
	 * e o outdegree.
	 */
	
	public Map<String,Integer> outdegree(ArrayList<String> actors, MultiMap interactions){
		
		DirectedSparseMultigraph<String, String> graph = this.generateGhaph(actors, interactions);
		
		Collection<String> vertices = graph.getVertices();
		
		Map<String,Integer> outdegreeValue = new HashMap<String, Integer>();
		
		int in;
		
		for (String student:vertices){
			in = graph.outDegree(student);
			outdegreeValue.put(student, in);
		}
		
		// Save graph
						
		this.saveGraph(graph);
		
		return outdegreeValue;
	}
	
	/*
	 * Gera um arquivo .graphml do grafo com o objetivo de ser plotado em ferramentas de visualização como Gephi e Pajek
	 */
	
	public void saveGraph(DirectedSparseMultigraph<String,String> graph){
		
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_hhmmss");
        Date date = new Date();
        String data = dateFormat.format(date);
		
		FileWriter file = null;
		try{
			file = new FileWriter(data + "graph.graphml");
			GraphMLWriter graphml = new GraphMLWriter();
			graphml.save(graph, file);
		}catch(Exception e) {System.out.println(e);};
	}
	
	/*
	 * Método que não está sendo utilizado pois o grafo já se comporta dessa maneira
	 */
	
	public MultiMap noDuplicatedInteractions(ArrayList<String> actors, MultiMap interactions){
	
		MultiMap clone = new MultiValueMap();
		ArrayList<String> edges = new ArrayList<String>();
		
		for (String j:actors){
			edges = (ArrayList<String>)interactions.get(j);
			if (edges != null){
				for (String i:edges){
					if (!(tuplaExist(i,(ArrayList<String>)clone.get(j)))){
						clone.put(j, i);
					}
				}
			}
			
		}
		
		System.out.println(clone);
		
		return clone;
		
	}
	
	/*
	 * Método que compara se há tuplas duplicadas no MultiMap.
	 * Método que não está sendo utilizado pois o grafo já se comporta dessa maneira.
	 */
	
	public boolean tuplaExist(String x, ArrayList<String> list){
		
		boolean exist = false;
		
		if (list != null){
			for (String i:list){
				if (x.equals(i)){
					exist = true;
				}
			}
		}
		
		return exist;
		
	}


}
